package com.crud.crud.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import com.crud.crud.dominio.Questao;
import com.crud.crud.repository.QuestaoRepository;


@Controller
@RequestMapping("/questoes")
public class QuestaoController {
	
	@Autowired
    private QuestaoRepository questaoRepository;
	

	@PostMapping("/novo")
	public ModelAndView novo(Questao questao) {
		
		ModelAndView modelAndView = new ModelAndView("questoes/form");
		modelAndView.addObject(questao);
		
		return modelAndView;
	}
	
	@PostMapping("/salvar")
	public ModelAndView salvar(@Valid Questao questao, BindingResult result,
			RedirectAttributes attributes) {
		
		questaoRepository.save(questao);
		
		ModelAndView modelAndView = new ModelAndView(new RedirectView("/questoes",true));
		
		return modelAndView;
	}
	
	@RequestMapping(value = "/{id}/editar", method = RequestMethod.GET)
	public ModelAndView editar(@PathVariable("id") Questao questao){
	
		ModelAndView modelAndView = new ModelAndView("/questoes/form");
		
		modelAndView.addObject("questao", questao);	
	
		return modelAndView;
	
	}
	
	@RequestMapping(value = "/{id}/excluir", method = RequestMethod.GET)
	public ModelAndView excluir(@PathVariable("id") Questao questao){
	
		questaoRepository.delete(questao);
		
		ModelAndView modelAndView = new ModelAndView(new RedirectView("/questoes",true));

		return modelAndView;
	
	}
	
	@GetMapping
	public String listar(Model model) {		
		model.addAttribute("questoes", questaoRepository.findAll());		
		return "questoes/list";
	}

}

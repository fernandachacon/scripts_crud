package br.com.crud.controller;

import java.util.List;

import br.com.crud.dao.SalaDAO;
import br.com.crud.dominio.Sala;

public class SalaController {

	SalaDAO salaDAO = new SalaDAO();;
	
	public List<Sala> listarSalas(){
		
		return salaDAO.listar();
	}
	
	public void salvar(Sala sala){
		
		salaDAO.adiciona(sala);
	}
	

	public void alterar(Sala sala){
		
		salaDAO.altera(sala);
	}
	
	public void remover(Sala sala){
		
		salaDAO.remove(sala);
	}
	
}

package br.com.crud.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.crud.ConnectionFactory;
import br.com.crud.dominio.Sala;

public class SalaDAO {
	
	private Connection connection;

    public SalaDAO() {
        this.connection = new ConnectionFactory().getConnection();
    }
    
    public List<Sala> listar(){
    	
    	String sql = "select * from sala";
    	
    	 try {
             PreparedStatement stmt = connection.prepareStatement(sql);
             
             ResultSet rs = stmt.executeQuery();
             
             List<Sala> salas = new ArrayList<Sala>();
             
             while (rs.next()) {

                 Sala sala = new Sala();
                 sala.setNome(rs.getString("nome"));
                 sala.setNumero(rs.getInt("numero"));

                 salas.add(sala);
             }

             
             stmt.execute();
             stmt.close();
             
             return salas;
             
         } catch (SQLException e) {
             throw new RuntimeException(e);
         }
    }
    
    public void adiciona(Sala sala) {
        String sql = "insert into sala " +
                "(id_sala, nome,numero)" +
                " values (?,?,?)";

        try {
            PreparedStatement stmt = connection.prepareStatement(sql);

            stmt.setInt(1,sala.getId());
            stmt.setString(2,sala.getNome());
            stmt.setInt(3, sala.getNumero());
            
            stmt.execute();
            stmt.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    
    public void altera(Sala sala) {
        String sql = "update sala set nome=?, numero=? where id_sala=?";
        
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
            
            stmt.setString(1, sala.getNome());
            stmt.setInt(2, sala.getNumero());
            stmt.setInt(3, sala.getId());
            
            stmt.execute();
            stmt.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    
    public void remove(Sala sala) {
        try {
            PreparedStatement stmt = connection.prepareStatement("delete " +
                    "from sala where id_sala=?");
            stmt.setLong(1, sala.getId());
            stmt.execute();
            stmt.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

}

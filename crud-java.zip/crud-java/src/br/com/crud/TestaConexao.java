package br.com.crud;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import br.com.crud.controller.SalaController;
import br.com.crud.dao.SalaDAO;
import br.com.crud.dominio.Sala;

public class TestaConexao {

	public static void main(String[] args) {
		
		Connection connection = new ConnectionFactory().getConnection();
        
        Sala sala = new Sala();
        sala.setId(13);
        sala.setNome("Caelum3");
        sala.setNumero(123456);

        SalaController salaController = new SalaController();

        salaController.salvar(sala);

        System.out.println("Gravado!");
        
        List<Sala> salas = salaController.listarSalas();
        
        for(int i = 0; i < salas.size(); i++){
        	System.out.print(salas.get(i).getNome()+"\n");
        }
        System.out.print("\n\n");
        
        Sala salaAltera = new Sala();
        salaAltera.setId(2);
        salaAltera.setNome("Fernanda");
        salaAltera.setNumero(12345678);
        
        salaController.alterar(salaAltera);
        
        List<Sala> salasAlteradas = salaController.listarSalas();
        
        for(int i = 0; i < salasAlteradas.size(); i++){
        	System.out.print(salasAlteradas.get(i).getNome()+"\n");
        }
        System.out.print("\n\n");
        
        
        Sala salaRemover = new Sala();
        salaRemover.setId(2);
        
        salaController.remover(salaRemover);
        
        List<Sala> salasDpsRemover = salaController.listarSalas();
        
        for(int i = 0; i < salasDpsRemover.size(); i++){
        	System.out.print(salasDpsRemover.get(i).getNome()+"\n");
        
        }
        System.out.print("\n\n");
        
        try {
			connection.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
